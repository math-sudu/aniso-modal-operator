"""Reproduce all eleven manuscript figures from the supplied data."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "code/figure_exports"))

import matplotlib.pyplot as plt
import manuscript_figures as methods


def main():
    spec = json.loads(methods.SPEC.read_text(encoding="utf-8"))
    methods.style()
    methods.verify_geometry(spec)
    for entry in spec["figures"]:
        job = entry["display_job_id"]
        figure, rows, checks = methods.DRAWERS[job](spec)
        destination = ROOT / "figures" / job
        destination.mkdir(parents=True, exist_ok=True)
        stem = destination / job.replace("-", "_")
        figure.savefig(stem.with_suffix(".pdf"),
                       metadata={"Creator": "Matplotlib", "CreationDate": None, "ModDate": None})
        figure.savefig(stem.with_suffix(".svg"), metadata={"Date": None, "Creator": "Matplotlib"})
        methods.save_csv(destination / "source_data.csv", rows)
        plt.close(figure)
        print("Wrote", stem.relative_to(ROOT), checks)
    for script in ("near_field_cloud_figures.py", "fig_dj18_exterior_cost.py",
                   "fig_dj19_lined_demo.py"):
        subprocess.run([sys.executable, "-B", str(ROOT / "code/figure_exports" / script)],
                       cwd=ROOT, check=True)
    print("Completed all eleven figures in figures/.")


if __name__ == "__main__":
    main()
