from __future__ import annotations
import csv
from pathlib import Path
import numpy as np
from _paperfig import FULL_MEASURE_IN, GUIDE, KEY1, KEY2, KEY3, TEXT, save_figure, figure_output_path, use_paper_style
import matplotlib.pyplot as plt
JOB = 'lined-section-demo'
SRC_SUM = 'results/data/derived/lined_demo_summary.csv'
SRC_ACT = 'results/data/derived/lined_demo_actions.csv'
C_BED = {90.0: KEY1, 45.0: KEY2, 0.0: KEY3}
LS_BED = {90.0: '-', 45.0: (0, (4.5, 1.6)), 0.0: (0, (1.4, 1.4))}
M_RATIO = {1.25: 'o', 2.625: 's', 4.0: '^'}
C_GUIDE = GUIDE
ACTION_RATIO = 4.0

def pin_ticks(ax) -> None:
    """Keep ticks within the displayed axis limits."""
    for axis, lim, setter in ((ax.xaxis, ax.get_xlim, ax.set_xticks), (ax.yaxis, ax.get_ylim, ax.set_yticks)):
        lo, hi = sorted(lim())
        span = hi - lo
        setter([t for t in axis.get_ticklocs() if lo - 1e-09 * span <= t <= hi + 1e-09 * span])

def load(rel: str) -> list[dict]:
    root = Path(__file__).resolve().parents[2]
    with (root / rel).open(encoding='utf-8') as fh:
        return list(csv.DictReader(fh))

def action_series(rows, ratio, dip, route):
    sel = [r for r in rows if float(r['ratio']) == ratio and float(r['material_dip_deg']) == dip and (r['route'] == route)]
    sel.sort(key=lambda r: float(r['station_theta_deg']))
    return (np.array([float(r['station_theta_deg']) for r in sel]), np.array([float(r['thrust_kN_per_m']) for r in sel]), np.array([float(r['moment_kNm_per_m']) for r in sel]))

def panel_actions(ax, rows, key: str, ylabel: str) -> None:
    idx = 1 if key == 'thrust' else 2
    for dip in (0.0, 45.0, 90.0):
        bed = 90.0 - dip
        th, n, m = action_series(rows, ACTION_RATIO, dip, 'condensed')
        y = (n, m)[idx - 1]
        ax.plot(th, y * 0.001 if key == 'thrust' else y, color=C_BED[bed], ls=LS_BED[bed], lw=1.1, label=f'bedding ${bed:.0f}\\degree$')
        tf, nf, mf = action_series(rows, ACTION_RATIO, dip, 'meshed_free')
        if len(tf):
            yf = (nf, mf)[idx - 1]
            ax.plot(tf[::8], (yf * 0.001 if key == 'thrust' else yf)[::8], ls='none', marker='o', ms=2.6, mfc='none', mec=C_BED[bed], mew=0.6)
    ax.set_xlim(0.0, 360.0)
    ax.set_xticks([0, 90, 180, 270, 360])
    ax.set_xlabel('boundary parameter $\\theta$ (deg)')
    ax.set_ylabel(ylabel)
    ax.grid(True, lw=0.3, alpha=0.35)

def panel_closure_map(ax, rows) -> None:
    lo, hi = (np.inf, 0.0)
    for dip in (0.0, 45.0, 90.0):
        bed = 90.0 - dip
        for ratio in (1.25, 2.625, 4.0):

            def q(route):
                for r in rows:
                    if r['route'] == route and float(r['ratio']) == ratio and (float(r['material_dip_deg']) == dip):
                        return (float(r['closure_horizontal_mm']), float(r['closure_vertical_mm']))
            xu, yu = q('unlined')
            xl, yl = q('condensed')
            lo = min(lo, xl, yl, xu, yu)
            hi = max(hi, xl, yl, xu, yu)
            ax.annotate('', xy=(xl, yl), xytext=(xu, yu), arrowprops=dict(arrowstyle='->', lw=0.7, color=C_BED[bed], alpha=0.75, linestyle=LS_BED[bed], shrinkA=1.5, shrinkB=1.5))
            ax.plot([xl], [yl], marker=M_RATIO[ratio], ms=4.2, color=C_BED[bed], ls='none')
            ax.plot([xu], [yu], marker=M_RATIO[ratio], ms=4.2, mfc='none', mec=C_BED[bed], mew=0.7, ls='none')
    pad = 0.06 * (hi - lo)
    lim = (lo - pad, hi + pad)
    ax.plot(lim, lim, ls=(0, (4, 3)), lw=0.7, color=C_GUIDE, zorder=0)
    ax.set_xlim(*lim)
    ax.set_ylim(*lim)
    ax.set_aspect('equal')
    ax.set_xlabel('horizontal closure (mm)')
    ax.set_ylabel('vertical closure (mm)')
    ax.grid(True, lw=0.3, alpha=0.35)

def row_key(fig) -> None:
    """Place one shared legend below the panel row."""
    handles = [plt.Line2D([], [], color=C_BED[b], ls=LS_BED[b], lw=1.1, label=f'bedding ${b:.0f}\\degree$') for b in (90.0, 45.0, 0.0)]
    handles += [plt.Line2D([], [], color='k', marker=M_RATIO[r], ms=4.2, mfc='none', ls='none', label=f'ratio {r:g}') for r in (1.25, 2.625, 4.0)]
    fig.legend(handles=handles, fontsize=6.4, ncol=6, loc='lower center', frameon=False, handletextpad=0.4, columnspacing=1.3, bbox_to_anchor=(0.5, 0.0))

def main() -> None:
    use_paper_style()
    summary, actions = (load(SRC_SUM), load(SRC_ACT))
    assert len(summary) == 18, f'summary slice has {len(summary)} rows'
    n_act = len([r for r in actions if r['route'] == 'condensed'])
    assert n_act == 9 * 128, f'condensed action slice has {n_act} rows'
    fig, axes = plt.subplots(1, 3, figsize=(FULL_MEASURE_IN, 2.3097))
    panel_actions(axes[0], actions, 'thrust', 'thrust (MN/m)')
    panel_actions(axes[1], actions, 'moment', 'bending moment (kNm/m)')
    panel_closure_map(axes[2], summary)
    for ax, tag in zip(axes.ravel(), 'abc'):
        ax.set_title(f'({tag})', loc='left', fontsize=7.0, pad=3.0)
        pin_ticks(ax)
    fig.tight_layout(pad=0.8, w_pad=1.4, h_pad=1.2, rect=(0.0, 0.085, 1.0, 1.0))
    row_key(fig)
    out = figure_output_path(JOB, 'lined_demo')
    save_figure(fig, out)
    print(f'  wrote {out}')
if __name__ == '__main__':
    main()
