from __future__ import annotations
import sys
from pathlib import Path
import matplotlib
import numpy as np
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT = Path(__file__).resolve().parents[2]
FIGURES = ROOT / 'figures'
MM_PER_IN = 25.4
TEX_PT_PER_IN = 72.27
FULL_MEASURE_IN = 412.56496 / TEX_PT_PER_IN
HALF_MEASURE_IN = 206.28248 / TEX_PT_PER_IN
KEY1 = '#1f4e79'
KEY2 = '#c05c24'
KEY3 = '#2e7d4f'
GUIDE = '#8c8c8c'
NEUTRAL = '#555555'
TEXT = '#333333'
WASH = '#e9e9e9'
FIELD_CMAP = {'physical': 'turbo'}
BANDS = 12
BAND_LINE_KW = dict(colors='k', linewidths=0.3, alpha=0.55)
NOISE_DECADES = 9.0

def band_lines(cs):
    """Clear the unused scalar array of a monochrome level-line ContourSet."""
    cs.set_array(None)
    return cs

class FigureQAError(RuntimeError):
    """An error-severity visual-QA finding blocked the save."""

class BandError(RuntimeError):
    """A filled field broke one of the discrete-band floors."""

def band_levels(vmin, vmax, n=BANDS, gamma=1.0, dense='low'):
    """``n + 1`` band edges over ``[vmin, vmax]``.

    ``gamma < 1`` crowds the edges toward one end, for a field whose area is
    piled up there while a thin tail runs to the other end -- the wall stress
    concentration is the standard case. ``dense`` names WHICH end gets the fine
    bands: ``"low"`` toward ``vmin``, ``"high"`` toward ``vmax``. The
    non-linearity is carried by the EDGES and not by a ``PowerNorm``, so every
    band still steps one colormap entry and the edges still print true values.
    """
    n = int(n)
    if n > BANDS:
        raise BandError(f'{n} bands requested; the convention caps filled fields at {BANDS} (sec 4c-3 item 4). Narrow the colour limits or add a zoom panel instead.')
    t = np.linspace(0.0, 1.0, n + 1)
    if gamma != 1.0:
        if dense == 'low':
            t = t ** (1.0 / float(gamma))
        elif dense == 'high':
            t = 1.0 - (1.0 - t) ** (1.0 / float(gamma))
        else:
            raise BandError(f"dense={dense!r}: expected 'low' or 'high'")
    return float(vmin) + (float(vmax) - float(vmin)) * t

def band_ticks(levels, every=2):
    """Colorbar ticks -- and the level lines -- ON band edges.

    A reader decodes a discrete band by counting it against the bar, so a tick
    that lands mid-band makes every band straddle two ticks. Both the black
    level lines and the bar ticks come through here, which is what makes them
    the same set: a line the reader can trace corresponds to a number they can
    read off.
    """
    return np.asarray(levels, float)[::int(every)]

def band_norm(levels, cmap, extend='neither'):
    """Return a BoundaryNorm assigning band i to colormap entry i.

Explicit band normalization preserves the intended colors for nonuniform level spacing, including the first and last colormap entries."""
    cm = matplotlib.colormaps[cmap] if isinstance(cmap, str) else cmap
    return matplotlib.colors.BoundaryNorm(np.asarray(levels, float), ncolors=cm.N, extend=extend)

def assert_band_colours(cf, where):
    """Reverse assertion: every band must print a DIFFERENT colour.

    This guards the RESULT of ``band_norm`` rather than its implementation, so
    it is not circular: the failure mode of edges and norm disagreeing is fixed
    -- several bands collapse onto one colormap entry while other entries are
    never used -- and that is exactly what this measures.
    """
    fc = np.asarray(cf.get_facecolor())
    if fc.ndim != 2 or fc.shape[0] < 2:
        return
    for i in range(fc.shape[0] - 1):
        d = np.abs(fc[i + 1:, :3] - fc[i, :3]).max(axis=1)
        j = int(np.argmin(d))
        if d[j] <= 1.5 / 255.0:
            raise BandError(f'{where}: band {i} and band {i + 1 + j} print the same colour RGB({round(255 * fc[i, 0])},{round(255 * fc[i, 1])},{round(255 * fc[i, 2])}); the edges and the norm disagree')

def field_tricontourf(ax, tri, z, levels, cmap, *, where, **kw):
    """Fill a triangulated field on discrete bands, with the colours checked."""
    cf = ax.tricontourf(tri, z, levels=levels, cmap=cmap, norm=band_norm(levels, cmap, kw.get('extend', 'neither')), **kw)
    assert_band_colours(cf, where)
    cf.set_edgecolor('face')
    return cf

def field_contourf(ax, X, Y, V, levels, cmap, *, where, **kw):
    """Fill a gridded field on discrete bands, with the colours checked."""
    cf = ax.contourf(X, Y, V, levels=levels, cmap=cmap, norm=band_norm(levels, cmap, kw.get('extend', 'neither')), **kw)
    assert_band_colours(cf, where)
    cf.set_edgecolor('face')
    return cf

def floor_machine_noise(values, *, name, decades=NOISE_DECADES):
    """Snap an arithmetic-noise pedestal to exact zero, and prove nothing moved.

    Returns ``(floored, report)``. ``report["decades"]`` is the separation the
    field ACTUALLY carries between its largest and smallest non-zero amplitude,
    so a field that is a field -- not a constant, not noise about zero -- is
    recorded as such with a number rather than passed through silently. Signed
    zeros are normalised to ``+0.0`` as well: ``-0.0`` and ``+0.0`` fall in
    different bands under a zero-crossing edge, so an equivalent rewrite of the
    same field would otherwise change its colour.
    """
    v = np.asarray(values, float)
    peak = float(np.abs(v).max())
    floor = peak * 10.0 ** (-float(decades))
    hit = np.abs(v) < floor
    out = np.where(hit, 0.0, v) + 0.0
    if float(np.abs(out).max()) != peak:
        raise BandError(f"{name}: flooring moved the field's own amplitude")
    nz = np.abs(out[out != 0.0])
    return (out, {'name': name, 'peak': peak, 'floor': floor, 'snapped': int((hit & (v != 0.0)).sum()), 'signed_zeros': int((v == 0.0).sum() and np.signbit(v[v == 0.0]).sum()), 'smallest_nonzero': float(nz.min()) if nz.size else 0.0, 'decades': float(np.log10(peak / nz.min())) if nz.size else float('inf')})

class BandOccupancy:
    """The two machine-checkable floors on a discrete-band field.

    Pooled over the whole case set, no single band may carry more than half the
    plotted cells -- that is the reading "the main body is squashed into one
    dead colour", made mechanical. Pooling hides the opposite failure, a single
    PANEL printing in one or two colours while the pooled figure stays healthy,
    so each panel separately must occupy at least three bands (two bands means
    one edge crosses the panel and there is no shape to read).
    """

    def __init__(self, levels, *, label):
        self.levels = np.asarray(levels, float)
        self.label = label
        self.panels: dict[str, np.ndarray] = {}

    def add(self, panel, values, weights):
        """Record one panel's share of each band, weighted by drawn area."""
        v = np.asarray(values, float)
        w = np.asarray(weights, float)
        idx = np.clip(np.digitize(v, self.levels) - 1, 0, self.levels.size - 2)
        share = np.array([w[idx == b].sum() for b in range(self.levels.size - 1)])
        self.panels[panel] = share / w.sum()
        return self.panels[panel]

    def report(self, *, max_share=0.5, min_bands=3, seen=0.0001):
        pooled = np.mean(list(self.panels.values()), axis=0)
        per = {k: (float(v.max()), int((v > seen).sum())) for k, v in self.panels.items()}
        return {'label': self.label, 'bands': int(self.levels.size - 1), 'pooled_max_share': float(pooled.max()), 'panel_max_share': max((s for s, _ in per.values())), 'min_bands_occupied': min((b for _, b in per.values())), 'per_panel': per, 'max_share': max_share, 'min_bands': min_bands}

    def assert_floors(self, *, max_share=0.5, min_bands=3, seen=0.0001):
        r = self.report(max_share=max_share, min_bands=min_bands, seen=seen)
        if r['bands'] > BANDS:
            raise BandError(f"{self.label}: {r['bands']} bands exceeds {BANDS}")
        if r['pooled_max_share'] >= max_share:
            raise BandError(f"{self.label}: one band carries {r['pooled_max_share'] * 100:.1f}% of the pooled field, at or over the {max_share * 100:.0f}% floor")
        if r['min_bands_occupied'] < min_bands:
            worst = min(r['per_panel'], key=lambda k: r['per_panel'][k][1])
            raise BandError(f"{self.label}: panel {worst} occupies only {r['per_panel'][worst][1]} band(s); the floor is {min_bands}")
        if r['panel_max_share'] >= max_share:
            worst = max(r['per_panel'], key=lambda k: r['per_panel'][k][0])
            raise BandError(f"{self.label}: panel {worst} puts {r['per_panel'][worst][0] * 100:.1f}% of its cells in one band, at or over the {max_share * 100:.0f}% floor")
        print(f"  bands {self.label}: {r['bands']} bands, pooled max {r['pooled_max_share'] * 100:.1f}%, worst panel {r['panel_max_share'] * 100:.1f}%, fewest occupied {r['min_bands_occupied']}")
        return r

def tri_cells(tri, x, y, z):
    """Centroid value and area of every triangle the mosaic actually fills.

    The occupancy floors are stated over PLOTTED CELLS, so they are measured on
    the drawn triangles of the masked triangulation, not on the nodal sample --
    a node count would weight the dense wall ring the same as the coarse far
    field and report an occupancy no reader can see.
    """
    t = tri.triangles[~tri.mask] if tri.mask is not None else tri.triangles
    px, py = (np.asarray(x)[t], np.asarray(y)[t])
    area = 0.5 * np.abs((px[:, 1] - px[:, 0]) * (py[:, 2] - py[:, 0]) - (px[:, 2] - px[:, 0]) * (py[:, 1] - py[:, 0]))
    return (np.asarray(z)[t].mean(axis=1), area)

def area_quantile(values, weights, q):
    """The level below which ``q`` per cent of the DRAWN AREA lies."""
    v, w = (np.asarray(values, float), np.asarray(weights, float))
    k = np.argsort(v)
    return float(np.interp(q / 100.0, np.cumsum(w[k]) / w.sum(), v[k]))

def use_paper_style() -> None:
    """Set serif figure text using the STIXGeneral font bundled with Matplotlib."""
    plt.rcParams.update({'font.family': 'serif', 'font.serif': ['STIXGeneral'], 'mathtext.fontset': 'stix', 'font.size': 8, 'axes.labelsize': 8, 'axes.titlesize': 8.5, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'xtick.minor.width': 0.5, 'ytick.minor.width': 0.5, 'lines.linewidth': 1.0, 'grid.linewidth': 0.4, 'grid.alpha': 0.25, 'legend.frameon': True, 'legend.framealpha': 0.92, 'legend.borderpad': 0.4, 'legend.handlelength': 1.8, 'pdf.fonttype': 42, 'savefig.bbox': 'standard', 'savefig.pad_inches': 0.01})

def figure_output_path(display_job_id: str, stem: str) -> Path:
    """``figures/<display_job_id>/<stem>.pdf``, parent created."""
    out = FIGURES / display_job_id / f'{stem}.pdf'
    out.parent.mkdir(parents=True, exist_ok=True)
    return out

def link_shared_colorbar(cbar, mappables) -> None:
    """Associate each mappable with the shared colorbar.

Require every mappable to use the same scale as the colorbar."""
    ref_levels = getattr(cbar.mappable, 'levels', None)
    for m in mappables:
        if m is cbar.mappable:
            continue
        assert m.cmap.name == cbar.mappable.cmap.name, f'shared colorbar: {m.cmap.name} != {cbar.mappable.cmap.name}'
        levels = getattr(m, 'levels', None)
        if ref_levels is not None or levels is not None:
            assert levels is not None and ref_levels is not None, 'shared colorbar: one mappable carries levels, another does not'
            assert len(levels) == len(ref_levels), 'shared colorbar: level count'
            assert all((abs(a - b) <= 1e-12 * max(1.0, abs(b)) for a, b in zip(levels, ref_levels))), 'shared colorbar: panels are not on the locked scale'
        else:
            assert m.norm.vmin == cbar.mappable.norm.vmin, 'shared colorbar vmin'
            assert m.norm.vmax == cbar.mappable.norm.vmax, 'shared colorbar vmax'
        m.colorbar = cbar

def colorbar_axes(fig, rect) -> 'plt.Axes':
    """Create manually positioned axes with Matplotlib's colorbar label."""
    cax = fig.add_axes(rect)
    cax.set_label('<colorbar>')
    return cax

def save_figure(fig, out_path, *, spec=None):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, metadata={'CreationDate': None})
    print('Wrote', out_path.relative_to(ROOT))
    return out_path
