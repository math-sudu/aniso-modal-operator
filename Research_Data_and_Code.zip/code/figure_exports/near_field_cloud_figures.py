from __future__ import annotations
import csv
import math
from pathlib import Path
import numpy as np
import matplotlib.tri as mtri
from matplotlib.path import Path as MplPath
from hs_section_geometry import source_polar_angle_deg
from _paperfig import BANDS, BAND_LINE_KW, FIELD_CMAP, FULL_MEASURE_IN, KEY1, KEY2, KEY3, NEUTRAL, TEXT, BandOccupancy, area_quantile, save_figure, band_levels, band_lines, band_ticks, colorbar_axes, field_tricontourf, figure_output_path, floor_machine_noise, link_shared_colorbar, tri_cells, use_paper_style
import matplotlib.pyplot as plt
ROOT = Path(__file__).resolve().parents[2]
DER = ROOT / 'results' / 'data' / 'derived'
RATIOS = ['1.250', '2.625', '4.000']
DIP_KEYS = ['90.0', '45.0', '0.0']
CASES = [(ratio, dip) for dip in DIP_KEYS for ratio in RATIOS]
STRESS_CLIP_PCT = 1.0
ERROR_CLIP_PCT = 95.0
ERROR_GAMMA = 1.0 / 1.7

def bedding_dip(dip_key) -> float:
    return float(dip_key)
RATIO_COLOR = {'1.250': KEY1, '2.625': KEY3, '4.000': KEY2}
DIP_STYLE = {'90.0': '-', '45.0': (0, (4.5, 1.6)), '0.0': (0, (1.4, 1.4))}
RATIO_WIDTH = {'1.250': 0.7, '2.625': 1.0, '4.000': 1.35}

def load(name):
    return list(csv.DictReader((DER / name).open(encoding='utf-8')))

def col(rows, key, f=float):
    return np.array([f(r[key]) for r in rows])
S = load('near_field_stress_hs100.csv')
H = load('wall_hoop_hs100.csv')
E = load('near_field_interface_error_hs100.csv')
D = load('near_field_displacement_hs100.csv')
SUM = load('near_field_case_summary.csv')

def _ordered_ring(rows, key=None, value=None):
    """A closed polyline of nodes, ordered by polar angle about the origin."""
    sel = rows if key is None else [r for r in rows if np.isclose(float(r[key]), value)]
    x, y = (col(sel, 'x_m'), col(sel, 'y_m'))
    k = np.argsort(np.arctan2(y, x))
    return (x[k], y[k])
wall = [r for r in H if r['E_ratio'] == '1.250' and r['bedding_dip_deg'] == '90.0']
o = np.argsort(col(wall, 'map_theta_deg'))
wx, wy = (col(wall, 'x_m')[o], col(wall, 'y_m')[o])
hole = MplPath(np.column_stack([wx, wy]))
_iface_src = [r for r in E if r['rho_out'] == '2.0' and r['E_ratio'] == '1.250' and (r['bedding_dip_deg'] == '90.0')]
ix, iy = _ordered_ring(_iface_src, 'node_grade', 2.0)
IFACE_CROWN = tuple(np.column_stack([ix, iy])[int(np.argmin(np.abs(np.arctan2(iy, ix) - math.pi / 2)))])

def _check_dip_convention() -> None:
    """The row labels are the CSV's own bedding dip, not the material dip.

    ``near_field_case_summary.csv`` carries both columns and they are
    complements, so the two are easy to swap; the identity below pins the labels
    to ``bedding_dip_deg`` and would fail the moment someone reintroduces the
    material dip as the label.
    """
    for r in SUM:
        assert abs(float(r['material_dip_deg']) + float(r['bedding_dip_deg']) - 90.0) < 1e-09, r['case']
        assert abs(bedding_dip(r['bedding_dip_deg']) - float(r['bedding_dip_deg'])) < 1e-09, r['case']

def _check_one_section() -> None:
    """The nine cases sweep the material, not the geometry: one outline."""
    for ratio, dip in CASES:
        rows = [r for r in H if r['E_ratio'] == ratio and r['bedding_dip_deg'] == dip]
        k = np.argsort(col(rows, 'map_theta_deg'))
        assert np.allclose(col(rows, 'x_m')[k], wx, atol=1e-09), (ratio, dip)
        assert np.allclose(col(rows, 'y_m')[k], wy, atol=1e-09), (ratio, dip)
        jx, jy = _ordered_ring([r for r in E if r['rho_out'] == '2.0' and r['E_ratio'] == ratio and (r['bedding_dip_deg'] == dip)], 'node_grade', 2.0)
        assert np.allclose(jx, ix, atol=1e-09) and np.allclose(jy, iy, atol=1e-09), f'interface polyline moved at {ratio}/{dip}'

def _check_geometry_furniture() -> None:
    """Neither piece of furniture may be drawn from a nominal radius.

    Both are polylines here, so the assertion is that a circle would be WRONG --
    if a later section made either of them round, drawing it as a polyline is
    still right, but the reverse shortcut would silently become available again
    and this row is what stops it being taken.
    """
    rw = np.hypot(wx, wy)
    assert rw.max() / rw.min() > 1.2, f'excavated wall spans only {rw.max() / rw.min():.4f}x in radius; a circle would now be a defensible shortcut, so re-read this'
    ri = np.hypot(ix, iy)
    assert (ri.max() - ri.min()) / ri.mean() > 0.05, f'truncation interface deviates only {(ri.max() - ri.min()) / ri.mean() * 100:.2f}% from a circle'
    print(f'  furniture: wall radius {rw.min():.4f}-{rw.max():.4f} m ({rw.max() / rw.min():.3f}x), interface {ri.min():.4f}-{ri.max():.4f} m ({(ri.max() - ri.min()) / ri.mean() * 100:.2f}% off a circle)')

def pick(rows, ratio, dip, **extra):
    out = [r for r in rows if r['E_ratio'] == ratio and r['bedding_dip_deg'] == dip]
    for k, v in extra.items():
        out = [r for r in out if r[k] == v]
    return out

def summary(ratio, dip, rho='2.0'):
    hit = [r for r in SUM if r['E_ratio'] == ratio and r['bedding_dip_deg'] == dip and (r['rho_out'] == rho)]
    assert len(hit) == 1, (ratio, dip, rho, len(hit))
    return hit[0]

def masked_tri(x, y):
    tri = mtri.Triangulation(x, y)
    cx = x[tri.triangles].mean(axis=1)
    cy = y[tri.triangles].mean(axis=1)
    tri.set_mask(hole.contains_points(np.column_stack([cx, cy])))
    return tri

def case_field(rows, valcol, *, name, **extra):
    """Every panel's triangulation, floored field and drawn cells, once.

    The colour limits are chosen from the pooled drawn cells and the occupancy
    floors are measured on them, so both come from what the mosaic actually
    fills rather than from the nodal sample.
    """
    out, cells, reports = ({}, {}, [])
    for ratio, dip in CASES:
        sel = pick(rows, ratio, dip, **extra)
        x, y = (col(sel, 'x_m'), col(sel, 'y_m'))
        z, rep = floor_machine_noise(col(sel, valcol), name=f'{name} {ratio}/{dip}')
        reports.append(rep)
        tri = masked_tri(x, y)
        out[ratio, dip] = (tri, x, y, z)
        cells[ratio, dip] = tri_cells(tri, x, y, z)
    snapped = sum((r['snapped'] for r in reports))
    assert snapped == 0, f'{name}: {snapped} cell(s) snapped to zero -- this field carries an arithmetic-noise pedestal and the caption must say so'
    worst = min(reports, key=lambda r: r['decades'])
    print(f"  noise floor {name}: 0 cells snapped, closest panel carries {worst['decades']:.2f} decades between its largest and smallest amplitude (floor fires under {1.0:.0f}e-9 of the peak)")
    return (out, cells, reports)

def panel_key(ratio, dip):
    return f'dip{dip}/ratio{ratio}'

def draw_wall(ax, lw=0.8):
    ax.plot(np.append(wx, wx[0]), np.append(wy, wy[0]), 'k-', lw=lw, zorder=6)

def draw_interface(ax, lw=0.9):
    ax.plot(np.append(ix, ix[0]), np.append(iy, iy[0]), '--', color='k', lw=lw, zorder=7)

def panel_axes(ax, i, j, xlim, ylim, xticks, yticks):
    ax.set_aspect('equal')
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    if i < 2:
        ax.set_xticklabels([])
    else:
        ax.set_xlabel('horizontal (m)', fontsize=7.4, labelpad=1.2)
    if j > 0:
        ax.set_yticklabels([])
    else:
        ax.set_ylabel('vertical (m)', fontsize=7.4, labelpad=1.2)
    ax.tick_params(labelsize=6.5, pad=1.5)

def headers(axes, row_dx=-0.3):
    """Name the two swept parameters once each, on the grid rather than the
    panels: a mosaic has a column and a row to hang them on, so nine panels
    carry two labels instead of eighteen."""
    for j, r in enumerate(RATIOS):
        axes[0][j].set_title(f'$E_h/E_v = {r}$', fontsize=7.6, pad=3.0)
    for i, d in enumerate(DIP_KEYS):
        axes[i][0].text(row_dx, 0.5, f'bedding dip {bedding_dip(d):.0f} deg', transform=axes[i][0].transAxes, rotation=90, va='center', ha='center', fontsize=7.6)
_NOTES: list = []

def panel_note(ax, text):
    _NOTES.append(ax.text(0.04, 0.035, text, transform=ax.transAxes, fontsize=6.2, bbox=dict(fc='w', ec='none', alpha=0.8, pad=1.2), zorder=9))

def assert_notes_fit(fig):
    """Every in-panel note stays inside the panel it belongs to.

    Nine panels are 1.77 in wide against two at 3.0, so the type sizes here are
    the smallest anything in this manuscript is set at and the notes are the
    longest strings on the mosaic. Whether they fit is decided by the RENDERER's
    measurement of the laid-out text against the axes, not by counting
    characters: a hand estimate of a string mixing digits, mathtext and a unit
    is not reliable enough to set a size against.
    """
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    worst = 1.0
    for t in _NOTES:
        ax = t.axes
        nb = t.get_window_extent(r)
        ab = ax.get_window_extent(r)
        if not (nb.x0 >= ab.x0 and nb.x1 <= ab.x1 and (nb.y0 >= ab.y0) and (nb.y1 <= ab.y1)):
            raise AssertionError(f'panel note {t.get_text()!r} leaves its panel: note [{nb.x0:.1f},{nb.x1:.1f}] against axes [{ab.x0:.1f},{ab.x1:.1f}]')
        worst = min(worst, (ab.x1 - nb.x1) / (ab.x1 - ab.x0))
    print(f'  notes: {len(_NOTES)} inside their panels, tightest right margin {worst * 100:.1f}% of the panel width')
    _NOTES.clear()

def overlay_legend(ax, **kw):
    handles = [plt.Line2D([], [], color=RATIO_COLOR[r], ls='-', lw=RATIO_WIDTH[r], label=f'$E_h/E_v = {r}$') for r in RATIOS] + [plt.Line2D([], [], color=NEUTRAL, ls=DIP_STYLE[d], lw=1.0, label=f'dip {bedding_dip(d):.0f} deg') for d in DIP_KEYS]
    return ax.legend(handles=handles, ncol=2, fontsize=6.2, framealpha=0.92, borderpad=0.35, columnspacing=1.0, handletextpad=0.5, handlelength=2.0, **kw)

def mosaic_figure(height_in, *, profile_ratio, spacer=0.06, left=0.1, right=0.861, top=0.957, bottom=0.067, hspace=0.16):
    """The 3 x 3 case matrix over a full-width summary panel.

    The summary sits under an empty spacer row rather than directly under the
    mosaic: at the mosaic's own row pitch the bottom row's axis label lands on
    the summary panel's top spine. ``spacer`` widens that gap when the carrier
    also has to park a mosaic-level key between the two.
    """
    fig = plt.figure(figsize=(FULL_MEASURE_IN, height_in))
    gs = fig.add_gridspec(5, 3, height_ratios=[1, 1, 1, spacer, profile_ratio], hspace=hspace, wspace=0.06, left=left, right=right, top=top, bottom=bottom)
    axes = [[fig.add_subplot(gs[i, j]) for j in range(3)] for i in range(3)]
    return (fig, gs, axes)

def render_stress_field():
    job = 'stress-field-mosaic'
    fields, cells, _ = case_field(S, 'sigma_3_MPa', name='sigma_3')
    zc = np.concatenate([c[0] for c in cells.values()])
    ac = np.concatenate([c[1] for c in cells.values()])
    lev = band_levels(area_quantile(zc, ac, STRESS_CLIP_PCT), zc.max(), BANDS)
    occ = BandOccupancy(lev, label='sigma_3')
    fig, gs, axes = mosaic_figure(6.2073, profile_ratio=0.64)
    drawn = []
    for n, (ratio, dip) in enumerate(CASES):
        i, j = divmod(n, 3)
        tri, x, y, z = fields[ratio, dip]
        ax = axes[i][j]
        cf = field_tricontourf(ax, tri, z, lev, FIELD_CMAP['physical'], where=f'{job} {panel_key(ratio, dip)}', extend='min')
        band_lines(ax.tricontour(tri, z, levels=band_ticks(lev), **BAND_LINE_KW))
        occ.add(panel_key(ratio, dip), *cells[ratio, dip])
        drawn.append(cf)
        draw_wall(ax)
        panel_axes(ax, i, j, (-10.5, 10.5), (-9.3, 9.3), [-10, -5, 0, 5, 10], [-8, -4, 0, 4, 8])
        row = summary(ratio, dip)
        delta = float(source_polar_angle_deg(float(row['peak_hoop_theta_deg'])))
        panel_note(ax, f"peak {float(row['peak_hoop_MPa']):.1f} MPa at $\\delta={delta:.1f}^\\circ$")
    headers(axes)
    occ.assert_floors()
    cb = fig.colorbar(drawn[-1], cax=colorbar_axes(fig, [0.88, 0.318, 0.015, 0.64]), ticks=band_ticks(lev))
    cb.set_label('minor principal stress $\\sigma_3$ (MPa)', fontsize=7.2)
    cb.ax.tick_params(labelsize=6.1)
    cb.outline.set_linewidth(0.5)
    link_shared_colorbar(cb, drawn)
    axb = fig.add_subplot(gs[4, :])
    for lo, hi in ((105, 120), (240, 255)):
        axb.axvspan(lo, hi, color=NEUTRAL, alpha=0.1, lw=0, zorder=1)
    for lo, hi in ((110, 120), (240, 250)):
        axb.axvspan(lo, hi, color=NEUTRAL, alpha=0.14, lw=0, zorder=1)
    for dip in DIP_KEYS:
        for ratio in RATIOS:
            h = pick(H, ratio, dip)
            delta = source_polar_angle_deg(col(h, 'map_theta_deg'))
            k = np.argsort(delta)
            axb.plot(delta[k], col(h, 'hoop_sigma_MPa')[k], ls=DIP_STYLE[dip], lw=RATIO_WIDTH[ratio], color=RATIO_COLOR[ratio], zorder=4)
    axb.set_xlim(0, 360)
    axb.set_xticks(range(0, 361, 45))
    axb.set_ylim(-95, -8)
    axb.set_yticks([-90, -70, -50, -30, -10])
    axb.set_xlabel('physical polar angle $\\delta$ (deg)', fontsize=7.0, labelpad=1.2)
    axb.set_ylabel('wall hoop stress (MPa)', fontsize=7.0, labelpad=1.2)
    axb.tick_params(labelsize=6.2, pad=1.5)
    axb.grid(alpha=0.22, ls=':', lw=0.4)
    axb.annotate("shaded: concentration bands reported by the section's source", xy=(128, -9.6), xytext=(0, 0), textcoords='offset points', fontsize=6.0, color=TEXT, ha='left', va='top', zorder=8, bbox=dict(fc='w', ec='none', alpha=0.85, pad=1.2))
    overlay_legend(axb, loc='lower center', bbox_to_anchor=(0.5, 0.015))
    assert_notes_fit(fig)
    spec = {'panels': [{} for _ in range(10)]}
    save_figure(fig, figure_output_path(job, 'stress_field'), spec=spec)
    plt.close(fig)

def render_interface_error():
    job = 'interface-transparency'
    fields, cells, _ = case_field(E, 'abs_diff_um', name='|du|', rho_out='2.0')
    ev = col([r for r in E if r['rho_out'] == '2.0'], 'abs_diff_um')
    lev = band_levels(0.0, float(np.percentile(ev, ERROR_CLIP_PCT)), BANDS, gamma=ERROR_GAMMA, dense='low')
    occ = BandOccupancy(lev, label='|du|')
    fig, gs, axes = mosaic_figure(6.5657, profile_ratio=0.58)
    drawn = []
    for n, (ratio, dip) in enumerate(CASES):
        i, j = divmod(n, 3)
        tri, x, y, z = fields[ratio, dip]
        ax = axes[i][j]
        cf = field_tricontourf(ax, tri, z, lev, FIELD_CMAP['physical'], where=f'{job} {panel_key(ratio, dip)}', extend='max')
        band_lines(ax.tricontour(tri, z, levels=band_ticks(lev), **BAND_LINE_KW))
        occ.add(panel_key(ratio, dip), *cells[ratio, dip])
        drawn.append(cf)
        draw_wall(ax)
        draw_interface(ax)
        if (i, j) == (0, 0):
            ax.annotate('$\\Gamma_\\rho$', xy=IFACE_CROWN, xytext=(0, -9), textcoords='offset points', fontsize=7.0, color='k', ha='center', va='top', zorder=9, bbox=dict(fc='w', ec='none', alpha=0.85, pad=1.0))
        panel_axes(ax, i, j, (-11.2, 11.2), (-11.2, 11.2), [-10, -5, 0, 5, 10], [-10, -5, 0, 5, 10])
        panel_note(ax, f"max {float(summary(ratio, dip)['max_abs_diff_um']):.1f} $\\mu$m")
    headers(axes)
    occ.assert_floors()
    cb = fig.colorbar(drawn[-1], cax=colorbar_axes(fig, [0.88, 0.3, 0.015, 0.658]), ticks=band_ticks(lev))
    cb.ax.set_yticklabels([f'{t_:.1f}' for t_ in band_ticks(lev)])
    cb.set_label('$|u_{\\mathrm{closed}} - u_{\\mathrm{reference}}|$ ($\\mu$m)', fontsize=7.2)
    cb.ax.tick_params(labelsize=6.1)
    cb.outline.set_linewidth(0.5)
    link_shared_colorbar(cb, drawn)
    axb = fig.add_subplot(gs[4, :])

    def station_profile(rows):
        g, z = (col(rows, 'node_grade'), col(rows, 'abs_diff_um'))
        grades = np.unique(np.round(g, 4))
        return (grades, np.array([z[np.isclose(g, gv)].mean() for gv in grades]))
    for dip in DIP_KEYS:
        for ratio in RATIOS:
            grades, prof = station_profile(pick(E, ratio, dip, rho_out='2.0'))
            assert len(grades) == 25, f'{ratio}/{dip}: {len(grades)} stations'
            assert np.all(np.diff(prof) <= 0), f'{ratio}/{dip} not monotone'
            axb.plot(grades, prof, ls=DIP_STYLE[dip], lw=RATIO_WIDTH[ratio], color=RATIO_COLOR[ratio], zorder=4)
    grades, prof = station_profile(pick(E, '2.625', '45.0', rho_out='1.5'))
    assert np.all(np.diff(prof) <= 0), 'rho=1.5 case not monotone'
    axb.plot(grades, prof, 'k-', lw=1.1, alpha=0.75, zorder=5)
    axb.text(1.13, 1.2, '$\\rho = 1.5$', fontsize=6.0, ha='center', va='center')
    for gv in (1.5, 2.0):
        axb.axvline(gv, color='k', ls=':', lw=0.7, zorder=2)
    axb.annotate('$\\Gamma_\\rho$', xy=(2.0, 0.95), xycoords=('data', 'axes fraction'), xytext=(-3, 0), textcoords='offset points', ha='right', va='top', fontsize=6.8)
    axb.set_xlim(0.98, 2.06)
    axb.set_ylim(0, 12)
    axb.set_xticks([1.0, 1.2, 1.4, 1.6, 1.8, 2.0])
    axb.set_yticks([0, 2, 4, 6, 8, 10, 12])
    axb.set_xlabel('radial position of the near-field node (1.0 = tunnel wall)', fontsize=7.0, labelpad=1.2)
    axb.set_ylabel('ring mean $|\\Delta u|$ ($\\mu$m)', fontsize=7.0, labelpad=1.2)
    axb.tick_params(labelsize=6.2, pad=1.5)
    axb.grid(alpha=0.22, ls=':', lw=0.4)
    overlay_legend(axb, loc='upper center', bbox_to_anchor=(0.6, 1.02))
    assert_notes_fit(fig)
    spec = {'panels': [{} for _ in range(10)]}
    save_figure(fig, figure_output_path(job, 'interface_error'), spec=spec)
    plt.close(fig)

def render_displacement_field():
    job = 'displacement-field'
    scale = 130.0
    fields, cells, _ = case_field(D, 'u_mag_mm', name='|u|')
    zc = np.concatenate([c[0] for c in cells.values()])
    lev = band_levels(zc.min(), zc.max(), BANDS)
    occ = BandOccupancy(lev, label='|u|')
    fig, gs, axes = mosaic_figure(6.7449, profile_ratio=0.56, spacer=0.22)
    drawn = []
    for n, (ratio, dip) in enumerate(CASES):
        i, j = divmod(n, 3)
        tri, x, y, z = fields[ratio, dip]
        ax = axes[i][j]
        cf = field_tricontourf(ax, tri, z, lev, FIELD_CMAP['physical'], where=f'{job} {panel_key(ratio, dip)}')
        band_lines(ax.tricontour(tri, z, levels=band_ticks(lev), **BAND_LINE_KW))
        occ.add(panel_key(ratio, dip), *cells[ratio, dip])
        drawn.append(cf)
        draw_wall(ax)
        d = pick(D, ratio, dip)
        on = col(d, 'on_wall', int).astype(bool)
        k = np.argsort(np.arctan2(y[on], x[on]))
        dx = x[on][k] + col(d, 'u_h_mm')[on][k] * 0.001 * scale
        dy = y[on][k] + col(d, 'u_v_mm')[on][k] * 0.001 * scale
        ax.plot(np.append(dx, dx[0]), np.append(dy, dy[0]), color='k', lw=1.0, ls=(0, (3.5, 1.8)), zorder=8)
        panel_axes(ax, i, j, (-11.2, 11.2), (-11.2, 11.2), [-10, -5, 0, 5, 10], [-10, -5, 0, 5, 10])
        row = summary(ratio, dip)
        panel_note(ax, f"max {float(row['max_wall_convergence_mm']):.2f} mm")
    headers(axes)
    occ.assert_floors()
    cb = fig.colorbar(drawn[-1], cax=colorbar_axes(fig, [0.88, 0.338, 0.015, 0.62]), ticks=band_ticks(lev))
    cb.ax.set_yticklabels([f'{t_:.2f}' for t_ in band_ticks(lev)])
    cb.set_label('displacement magnitude (mm)', fontsize=7.2)
    cb.ax.tick_params(labelsize=6.1)
    cb.outline.set_linewidth(0.5)
    link_shared_colorbar(cb, drawn)
    axb = fig.add_subplot(gs[4, :])
    for gv, name, va, dy in ((0.0, 'springline', 'bottom', 3), (-90.0, 'invert', 'top', -3)):
        axb.axhline(gv, color='k', ls=':', lw=0.7, zorder=2)
        axb.annotate(name, xy=(47.0, gv), xytext=(0, dy), textcoords='offset points', fontsize=6.0, ha='left', va=va, color=TEXT)
    for ratio in RATIOS:
        dips, angs = ([], [])
        for dip in DIP_KEYS:
            d = pick(D, ratio, dip)
            on = col(d, 'on_wall', int).astype(bool)
            k = int(np.argmax(col(d, 'u_mag_mm')[on]))
            xw, yw = (col(d, 'x_m')[on][k], col(d, 'y_m')[on][k])
            dips.append(bedding_dip(dip))
            angs.append(math.degrees(math.atan2(yw, abs(xw))))
        o = np.argsort(dips)
        axb.plot(np.array(dips)[o], np.array(angs)[o], '-o', lw=RATIO_WIDTH[ratio], ms=3.2, color=RATIO_COLOR[ratio], zorder=4, label=f'$E_h/E_v = {ratio}$')
    axb.set_xlim(-5, 95)
    axb.set_xticks([0, 15, 30, 45, 60, 75, 90])
    axb.set_ylim(-105, 27)
    axb.set_yticks([-90, -60, -30, 0])
    axb.set_xlabel('bedding dip from the horizontal (deg)', fontsize=7.0, labelpad=1.2)
    axb.set_ylabel('wall maximum, deg\nfrom the horizontal', fontsize=7.0, labelpad=1.2)
    axb.tick_params(labelsize=6.2, pad=1.5)
    axb.grid(alpha=0.22, ls=':', lw=0.4)
    axb.legend(loc='upper left', fontsize=6.2, framealpha=0.92, borderpad=0.35, handletextpad=0.5, handlelength=2.0, borderaxespad=0.3)
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    inv = fig.transFigure.inverted()
    above = min((axes[2][j].get_tightbbox(r).transformed(inv).y0 for j in range(3)))
    below = axb.get_tightbbox(r).transformed(inv).y1
    assert above - below > 0.03, f'no room between the mosaic ({above:.4f}) and the summary panel ({below:.4f}) for the mosaic key'
    key = fig.legend(handles=[plt.Line2D([], [], color='k', lw=0.8, label='excavated section'), plt.Line2D([], [], color='k', lw=1.0, ls=(0, (3.5, 1.8)), label=f'deformed wall, $\\times{scale:.0f}$')], loc='center', bbox_to_anchor=(0.482, 0.5 * (above + below)), ncol=2, fontsize=6.6, framealpha=0.92, borderpad=0.35, columnspacing=1.5, handletextpad=0.6, handlelength=2.1)
    fig.canvas.draw()
    kb = key.get_window_extent(r).transformed(inv)
    assert kb.y1 < above and kb.y0 > below, f'the mosaic key {kb.y0:.4f}-{kb.y1:.4f} overlaps the mosaic ({above:.4f}) or the summary panel ({below:.4f})'
    assert_notes_fit(fig)
    spec = {'panels': [{} for _ in range(10)]}
    save_figure(fig, figure_output_path(job, 'displacement_field'), spec=spec)
    plt.close(fig)

def main() -> None:
    _check_dip_convention()
    _check_one_section()
    _check_geometry_furniture()
    use_paper_style()
    render_stress_field()
    render_interface_error()
    render_displacement_field()
if __name__ == '__main__':
    main()
