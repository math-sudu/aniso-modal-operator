"""Check the distributed numerical modules on small existing analytical cases."""

import importlib
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
for folder in ("lib", "code/closure", "code/closure/numeric", "code/figure_exports"):
    sys.path.insert(0, str(ROOT / folder))

from exec20_src.material import material_F
from exec26_src.geometry import SectionMap
from exec26_src.sf_twoterm import modal_blocks_density
from p21_exact_evaluation import assemble_exact, heldout_certificate
from p22_graded_kernels import closed_S1, closed_S2


def main():
    # Import the complete distributed computation chain without solving fields.
    bundled_modules = set()
    for path in sorted((ROOT / "lib").rglob("*.py")):
        relative = path.relative_to(ROOT / "lib").with_suffix("")
        parts = list(relative.parts)
        if parts[-1] == "__init__":
            parts.pop()
        if parts:
            bundled_modules.add(".".join(parts))
    for folder in ("code/closure", "code/closure/numeric", "code/figure_exports"):
        bundled_modules.update(path.stem for path in (ROOT / folder).glob("*.py"))
    for name in sorted(bundled_modules):
        importlib.import_module(name)
    mat = material_F(3.0, 45.0)
    reference = modal_blocks_density(mat, 3)
    for shape in (SectionMap(1.0, [0.0]), SectionMap(2.0, [0.0, 0.3])):
        result = assemble_exact(mat, shape, 3, 12)
        error = np.linalg.norm(result["S"] - reference) / np.linalg.norm(reference)
        residual = heldout_certificate(result)
        if error > 1e-10 or residual > 1e-10:
            raise AssertionError((error, residual))
        print(f"Exact two-term block: relative error {error:.3e}; residual {residual:.3e}")
    zero = np.zeros(4, dtype=complex)
    if np.linalg.norm(closed_S1(mat, 1.0, zero, 3)) > 1e-12 \
            or np.linalg.norm(closed_S2(mat, 1.0, zero, 3)) > 1e-12:
        raise AssertionError("Zero map perturbation must have zero correction kernels")
    external = []
    for name in sorted(bundled_modules):
        module = sys.modules[name]
        filename = getattr(module, "__file__", None)
        if filename is None or not Path(filename).resolve().is_relative_to(ROOT):
            external.append((name, filename))
    if external:
        raise AssertionError(f"Unexpected external project imports: {external}")
    print("Standalone solver imports and zero-perturbation checks passed.")


if __name__ == "__main__":
    main()
